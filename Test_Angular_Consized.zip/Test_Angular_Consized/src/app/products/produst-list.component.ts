import { Component, OnInit } from "@angular/core";
import { IProduct } from "./products";
import { ProductService } from "./product.service";

@Component({
selector:'pm-products',
templateUrl:'./product-list.component.html',
styleUrls:['./product-list.component.css']
})
export class ProductListComponent implements OnInit{
pageTitle :string ='Product List';
imagewidth:number =50;
imagemargin:number=2;
showimage:boolean =false;
//listFilter:string='cart';

_listFilter:string;
  errorMessage: string;
get listFilter(){
  return this._listFilter;
}
set listFilter(val:string){
  this._listFilter =val;
  this.filterProducts = this.listFilter ? this.performFilter(this.listFilter) : this.products;

}

filterProducts:IProduct[];
products:IProduct[] ;
   
    constructor(private productService: ProductService){
      //this.listFilter ='cart';
    }
    performFilter(filterBy:string):IProduct[]{
        filterBy = filterBy.toLowerCase();
        return this.products.filter( 
                (product:IProduct) => product.productName.toLowerCase().indexOf(filterBy) !==-1 
          )
    }
    onRatingClicked(message :string) :void {
     this.pageTitle = 'product List : ' + message ;
    }
    toggleImage():void {
      this.showimage =!this.showimage;
  }
  ngOnInit():void {
    this.productService.getProducts().subscribe(
      product => {
      this.products = product ;
      this.filterProducts = this.products;
    },
      error => this.errorMessage = <any>error        
    ) ;
  }
}